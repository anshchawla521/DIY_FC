//http://www.a1k0n.net/js/donut.js
//modified to make it 40x11 - not 80x22, and to use arraybuffers for memory usage
  var A=0.5, B=1;

/* ORIGINAL
  var asciiframe=function() {
    var b=[];
    var z=[];
    A += 0.07;
    B += 0.03;
    var cA=Math.cos(A), sA=Math.sin(A),
        cB=Math.cos(B), sB=Math.sin(B);
    for(var k=0;k<1760;k++) {
      b[k]=k%80 == 79 ? "\n" : " ";
      z[k]=0;
    }
    for(var j=0;j<6.28;j+=0.07) { // j <=> theta
      var ct=Math.cos(j),st=Math.sin(j);
      for(i=0;i<6.28;i+=0.02) {   // i <=> phi
        var sp=Math.sin(i),cp=Math.cos(i),
            h=ct+2, // R1 + R2*cos(theta)
            D=1/(sp*h*sA+st*cA+5), // this is 1/z
            t=sp*h*cA-st*sA; // this is a clever factoring of some of the terms in x' and y'

        var x=0|(40+30*D*(cp*h*cB-t*sB)),
            y=0|(12+15*D*(cp*h*sB+t*cB)),
            o=x+80*y,
            N=0|(8*((st*sA-sp*ct*cA)*cB-sp*ct*sA-st*cA-cp*ct*sB));
        if(y<22 && y>=0 && x>=0 && x<79 && D>z[o])
        {
          z[o]=D;
          b[o]=".,-~:;=!*#$@"[N>0?N:0];
        }
      }
    }
   // print(b.join(""));
  };
*/

function asciiframe() {
  var b = new Uint8Array(440);
  var z = new Float32Array(440)
  A += 0.07;
  B += 0.03;
  var cA=Math.cos(A), sA=Math.sin(A),
      cB=Math.cos(B), sB=Math.sin(B);
  for(var j=0;j<6.28;j+=0.14) { // j <=> theta
    var ct=Math.cos(j),st=Math.sin(j);
    for(i=0;i<6.28;i+=0.04) {   // i <=> phi
      var sp=Math.sin(i),cp=Math.cos(i),
          h=ct+2, // R1 + R2*cos(theta)
          D=1/(sp*h*sA+st*cA+5), // this is 1/z
          t=sp*h*cA-st*sA; // this is a clever factoring of some of the terms in x' and y'

      var x=0|(20+15*D*(cp*h*cB-t*sB)),
          y=0|(6+7.5*D*(cp*h*sB+t*cB)),
          o=x+40*y,
          N=0|(8*((st*sA-sp*ct*cA)*cB-sp*ct*sA-st*cA-cp*ct*sB));
      if(y<22 && y>=0 && x>=0 && x<79 && D>z[o])
      {
        z[o]=D;
        b[o]=".,-~:;=!*#$@".charCodeAt(N>0?N:0);
      }
    }
  }
  for(var k=0;k<b.length;k+=40) {
    b[k+38] = 13;
    b[k+39] = 10;
    z[k]=0;
  }
  print(E.toString(b));
}

asciiframe();
