# Security Policy

## Supported Versions

We are currently providing software updates for all [official Espruino devices](https://www.espruino.com/Order).

## Reporting a Vulnerability

To report a vulnerability please just create a [GitHub issue](https://github.com/espruino/Espruino/issues).

If you feel the vulnerability is extremely serious and could be exploited if details were published,
please contact us by email at gw@espruino.com.
